from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
import pymysql.cursors
import os
from dotenv import load_dotenv
import logging

load_dotenv()  # .env 파일에서 환경 변수 로드

app = FastAPI()

# CORS 설정
origins = [
    "*",  # 모든 도메인 허용
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 데이터베이스 연결 설정
def get_db_connection():
    return pymysql.connect(
        host=os.getenv('DB_HOST', 'localhost'),
        user=os.getenv('DB_USER', 'root'),
        password=os.getenv('DB_PASSWORD', '0000'),  # 실제 비밀번호로 수정 필요
        database=os.getenv('DB_NAME', 'submission_db'),
        cursorclass=pymysql.cursors.DictCursor,
        charset='utf8mb4'
    )

# 제출 내역 저장 함수
def save_submission(username, password, code):
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            cursor.execute(
                "INSERT INTO submission (username, password, code, status, created_at, updated_at) VALUES (%s, %s, %s, 'SUBMITTED', %s, %s)",
                (username, password, code, current_time, current_time)
            )
            connection.commit()
            submission_id = cursor.lastrowid
            submission_dir = "/Users/chaeeunseong/Documents/cash/submissions"  # 실제 저장 경로로 수정
            os.makedirs(submission_dir, exist_ok=True)
            with open(f"{submission_dir}/{submission_id}.py", "w") as file:
                file.write(code)
    except Exception as e:
        connection.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to save submission: {str(e)}")
    finally:
        connection.close()

    return submission_id

# 제출 내역 조회 함수
def get_submission(username, id):
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT * FROM submission WHERE username = %s AND id = %s",
                (username, id)
            )
            submission = cursor.fetchone()
            if not submission:
                raise HTTPException(status_code=404, detail="Submission not found")
    except Exception as e:
        logger.error(f"Error getting submission: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get submission: {str(e)}")
    finally:
        connection.close()

    return submission

# 요청 바디 모델 정의
class SubmissionRequest(BaseModel):
    username: str
    password: str
    code: str

class SubmissionUpdate(BaseModel):
    id: int
    result: str  # CORRECT, INCORRECT, ERROR 중 하나

# 코드 제출 및 평가
@app.post("/submission")
def create_submission(submission: SubmissionRequest):
    try:
        submission_id = save_submission(submission.username, submission.password, submission.code)
        if submission.code.strip() == 'print("Hello World!")':
            status = "CORRECT"
        else:
            status = "INCORRECT"
        
        update_submission_status(submission_id, status)
        return {"id": submission_id, "status": status}
    except Exception as e:
        logger.error(f"Error creating submission: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# 제출 내역 조회
@app.get("/submission")
def read_submission(username: str, password: str, id: int):
    try:
        submission = get_submission(username, id)
        if submission:
            if submission['password'] == password:
                return submission
            else:
                raise HTTPException(status_code=401, detail="Unauthorized")
        else:
            raise HTTPException(status_code=404, detail="Submission not found")
    except Exception as e:
        logger.error(f"Error reading submission: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# PATCH 메서드 구현
@app.patch("/submission")
def update_submission(submission: SubmissionUpdate):
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            sql = "UPDATE submission SET status = %s, updated_at = %s WHERE id = %s"
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            cursor.execute(sql, (submission.result, current_time, submission.id))
            connection.commit()
            return {"message": "Submission updated successfully"}
    except Exception as e:
        connection.rollback()
        logger.error(f"Error updating submission: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to update submission: {str(e)}")
    finally:
        connection.close()

# 제출 상태 업데이트 함수
def update_submission_status(submission_id, status):
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            sql = "UPDATE submission SET status = %s, updated_at = %s WHERE id = %s"
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            cursor.execute(sql, (status, current_time, submission_id))
            connection.commit()
    except Exception as e:
        connection.rollback()
        logger.error(f"Error updating submission status: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to update submission status: {str(e)}")
    finally:
        connection.close()

#!/bin/bash

# 데이터베이스 연결 설정
DB_HOST="localhost"
DB_USER="root"
DB_PASS="0000"
DB_NAME="submission_db"

# 가장 오래된 SUBMITTED 상태의 항목 가져오기
submission=$(mysql -h $DB_HOST -u $DB_USER -p$DB_PASS $DB_NAME -se "SELECT id, code FROM submission WHERE status = 'SUBMITTED' ORDER BY created_at LIMIT 1")

if [ -z "$submission" ]; then
    echo "No submissions to grade."
    exit 0
fi

submission_id=$(echo $submission | awk '{print $1}')
submission_code=$(echo $submission | cut -d' ' -f2-)

# 정답 코드와 제출된 코드 비교
if [ "$submission_code" == 'print("Hello World!")' ]; then
    RESULT="CORRECT"
else
    RESULT="INCORRECT"
fi

# 상태 업데이트 및 현재 시각 설정
UPDATED_AT=$(date '+%Y-%m-%d %H:%M:%S')
mysql -h $DB_HOST -u $DB_USER -p$DB_PASS $DB_NAME -e "UPDATE submission SET status = '$RESULT', updated_at = '$UPDATED_AT' WHERE id = $submission_id"

# 관리 서버에 결과 전달
curl -X PATCH "http://localhost:8000/submission" -H "Content-Type: application/json" -d "{\"id\": $submission_id, \"result\": \"$RESULT\"}"

echo "Grading completed for submission ID: $submission_id with result: $RESULT"

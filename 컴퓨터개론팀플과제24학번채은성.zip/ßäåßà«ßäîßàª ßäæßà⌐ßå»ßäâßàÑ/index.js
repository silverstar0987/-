document.getElementById('submission-form').addEventListener('submit', async function(event) {
    event.preventDefault();  // 폼의 기본 동작(페이지 리로드)을 막습니다.

    // 폼 필드 값 가져오기
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const code = document.getElementById('code').value;

    // 전송할 데이터 객체 생성
    const payload = {
        username: username,
        password: password,
        code: code
    };

    try {
        // 서버로 POST 요청 보내기
        const response = await axios.post('http://localhost:8000/submission', payload);

        // 서버로부터 응답 받기
        document.getElementById('results').innerText = `Submission received with ID: ${response.data.id}, Status: ${response.data.status}`;
    } catch (error) {
        // 에러 처리
        document.getElementById('results').innerText = `Error submitting code: ${error.response ? error.response.data.detail : error.message}`;
    }
});

document.getElementById('submission-query-form').addEventListener('submit', async function(event) {
    event.preventDefault();  // 폼의 기본 동작(페이지 리로드)을 막습니다.

    // 폼 필드 값 가져오기
    const username = document.getElementById('query-username').value;
    const password = document.getElementById('query-password').value;
    const id = document.getElementById('query-id').value;

    try {
        // 서버로 GET 요청 보내기
        const response = await fetch(`http://localhost:8000/submission?username=${username}&password=${password}&id=${id}`);
        const data = await response.json();

        if (response.ok) {
            document.getElementById('results').innerText = JSON.stringify(data, null, 2);
        } else {
            document.getElementById('results').innerText = `Error: ${data.detail}`;
        }
    } catch (error) {
        document.getElementById('results').innerText = `Error: ${error.message}`;
    }
});

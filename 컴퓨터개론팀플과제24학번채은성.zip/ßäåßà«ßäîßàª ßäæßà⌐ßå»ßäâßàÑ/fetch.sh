#!/bin/bash

# 관리 서버의 URL 설정
MANAGE_SERVER_URL="http://localhost:8000/submission"

# HTTP GET 요청 보내기
curl -X GET "${MANAGE_SERVER_URL}/new"
